const container = document.getElementById("container");
const registerBtn = document.getElementById("register");

const loginBtn = document.getElementById("login");

registerBtn.addEventListener("click", () => {
    container.classList.add("active");
});

loginBtn.addEventListener("click", () => {
    container.classList.remove("active");
});




function myFunction() {
  var x = document.getElementById("myinput2");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}



function myFunction() {
    var x = document.getElementById("myinput1");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }